/*
 * I2C_test.h
 *
 *  Created on: 2020-12-18
 *      Author: GDR
 */

#ifndef INC_I2C_TEST_H_
#define INC_I2C_TEST_H_

#define Si5351_I2C_TEST_ADDR  	0xC0
#define SHTC1_I2C_TEST_ADDR  	0xE0
#define SGP30_I2C_TEST_ADDR  	0xB0
#define SGP40_I2C_TEST_ADDR  	0xB2
#define BMP388_I2C_TEST_ADDR  	0xEC
#define BMP390_I2C_TEST_ADDR  	0xEC

_Bool I2C_Devices_Check(I2C_HandleTypeDef hi2c);


#endif /* INC_I2C_TEST_H_ */
