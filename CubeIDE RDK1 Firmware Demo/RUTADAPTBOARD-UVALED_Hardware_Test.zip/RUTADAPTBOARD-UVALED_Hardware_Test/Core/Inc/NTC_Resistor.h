/*
 * NTC_Resistor.h
 *
 *  Created on: 2020-12-18
 *      Author: GDR
 */

#ifndef INC_NTC_RESISTOR_H_
#define INC_NTC_RESISTOR_H_

extern int NTC_table[1025];
int NTC_ADC2Temperature(unsigned int adc_value);

#endif /* INC_NTC_RESISTOR_H_ */
