/*
 * PWM_test.h
 *
 *  Created on: Dec 18, 2020
 *      Author: GDR
 */

#ifndef INC_PWM_TEST_H_
#define INC_PWM_TEST_H_

#define LED_TIMER	TIM2
#define FAN_TIMER	TIM5

void LED_PWM_setvalue(TIM_HandleTypeDef *led_handle, uint32_t value);
void FAN_PWM_setvalue(TIM_HandleTypeDef *fan_handle, uint32_t value);
void PWMOutputsTest(void);

#endif /* INC_PWM_TEST_H_ */
