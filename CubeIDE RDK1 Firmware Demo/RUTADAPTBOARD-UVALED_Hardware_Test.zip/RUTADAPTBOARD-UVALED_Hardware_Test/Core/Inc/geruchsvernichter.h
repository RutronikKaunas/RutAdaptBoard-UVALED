#ifndef __GERUCHSVERNICHTER_H
#define __GERUCHSVERNICHTER_H

#ifdef __cplusplus
 extern "C" {
#endif


#include "main.h"


// Sensirion Functions

void Sensirion_checkI2C(void);									// Check I2C-Communikation	- SGP30
void Sensirion_measureRHT(void);								// Measurement	- SHTC1
void Sensirion_initSGP(void);									// Initialize	- SGP30
void Sensirion_measureSGP(void);								// Measurement	- SGP30
void Sensirion_HumiCompensation(void);							// Humi.update & compensate	- SGP30
//void Sensirion_error(uint8_t);								// Check errors	- Sensirion SGP30&SHTC1

//static uint8_t crc8(const uint8_t* data, uint8_t len);		// Calculation of CRC_8bit	- SGP30

void Si5351(void);												// Clock Generator	- Si5351
//void Si5351_error(uint8_t);									// Check errors		- Si5351

void RUT_RNG(void);												// Random number generator
void RUT_PrimeNumberChecker(void);								// Check Prime Number


#ifdef __cplusplus
}
#endif

#endif
