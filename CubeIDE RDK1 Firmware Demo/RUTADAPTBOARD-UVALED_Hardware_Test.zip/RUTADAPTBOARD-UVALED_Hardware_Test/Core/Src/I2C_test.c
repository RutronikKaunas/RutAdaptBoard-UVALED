/*
 * I2C_test.c
 *
 *  Created on: 2020-12-18
 *      Author: GDR
 */


#include "main.h"
#include "I2C_test.h"
#include "stdio.h"

_Bool I2C_Devices_Check(I2C_HandleTypeDef hi2c)
{
	_Bool test_sts = 1;

	printf("IIC Devices Test Initiated. \n\r");

	/*Look for Si5351 Clock Generator*/
	HAL_GPIO_WritePin(GEN_EN_GPIO_Port, GEN_EN_Pin, GPIO_PIN_SET);
	HAL_Delay(10);
    if(HAL_I2C_IsDeviceReady(&hi2c, Si5351_I2C_TEST_ADDR, 2, 2) != HAL_OK)
    {
    	printf("Si5351 Clock Generator NOT DETECTED. \n\r");
    	test_sts = 0;
    }
    else
    {
    	printf("Si5351 Clock Generator is Connected. \n\r");
    }

    /*Look for SHTC1 Temperature & Humidity Sensor*/
    if(HAL_I2C_IsDeviceReady(&hi2c, SHTC1_I2C_TEST_ADDR, 2, 2) != HAL_OK)
    {
    	printf("SHTC1 Temperature & Humidity Sensor NOT DETECTED. \n\r");
    	test_sts = 1;
    }
    else
    {
    	printf("SHTC1 Temperature & Humidity Sensor is Connected. \n\r");
    }

    /*Look for SGP40 Air Quality Sensor*/
    if(HAL_I2C_IsDeviceReady(&hi2c, SGP40_I2C_TEST_ADDR, 2, 2) != HAL_OK)
    {
    	printf("SGP40 Air Quality Sensor NOT DETECTED. \n\r");
    	test_sts = 1;
    }
    else
    {
    	printf("SGP40 Air Quality Sensor is Connected. \n\r");
    }

    /*Look for BMP390 Pressure Sensor*/
    if(HAL_I2C_IsDeviceReady(&hi2c, BMP390_I2C_TEST_ADDR, 2, 2) != HAL_OK)
    {
    	printf("BMP390 Pressure Sensor NOT DETECTED. \n\r");
    	test_sts = 1;
    }
    else
    {
    	printf("BMP390 Pressure Sensor is Connected. \n\r");
    }

    HAL_GPIO_WritePin(GEN_EN_GPIO_Port, GEN_EN_Pin, GPIO_PIN_RESET);
    return test_sts;
}
