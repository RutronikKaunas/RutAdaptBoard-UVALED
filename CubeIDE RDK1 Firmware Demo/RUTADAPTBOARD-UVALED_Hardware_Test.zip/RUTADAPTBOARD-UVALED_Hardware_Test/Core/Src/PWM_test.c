/*
 * PWM_test.c
 *
 *  Created on: Dec 18, 2020
 *      Author: GDR
 */


#include "main.h"
#include "PWM_test.h"
#include "stdio.h"

void LED_PWM_setvalue(TIM_HandleTypeDef *led_handle, uint32_t value)
{
	if((led_handle->Instance = LED_TIMER) && (led_handle->Init.Period >= value))
	{
		led_handle->Instance->CCR1 = value;
	}
}

void FAN_PWM_setvalue(TIM_HandleTypeDef *fan_handle, uint32_t value)
{
	if((fan_handle->Instance = FAN_TIMER) && (fan_handle->Init.Period >= value))
	{
		fan_handle->Instance->CCR1 = value;
	}
}

void PWMOutputsTest(void)
{
	uint32_t i = 0;

	printf("PWM outputs test has started.\n\r");
	HAL_Delay(100);

	/*LED PWM Timer Start*/
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
	LED_PWM_setvalue(&htim2, 0);

	/*FAN PWM Timer Start*/
	HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_1);
	FAN_PWM_setvalue(&htim5, 0);

	printf("PWM Outputs are set to MINIMUM.\n\r");
	HAL_Delay(1000);

	/*Slowly increase the duty cycle to the maximum*/
	do
		{
			i += 50;
			LED_PWM_setvalue(&htim2, i);
			FAN_PWM_setvalue(&htim5, i);
			HAL_Delay(1);
		}
	while(i<100000);

	printf("PWM Outputs are set to MAXIMUM.\n\r");
	HAL_Delay(5000);

	HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);
	HAL_TIM_PWM_Stop(&htim5, TIM_CHANNEL_1);

	printf("PWM outputs test is over.\n\r");
	HAL_Delay(1000);
}
