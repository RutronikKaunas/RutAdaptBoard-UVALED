/*	
 *	Geraete :		STM32G431,  Sensirion SHTC1,  Sensirion SGP30,  Si5351A(10-MSOP)
 *	Dokumente :		Silicon Labs - AN619
 *	Rutronik GmbH (by ZQI, GDR)
 */

#include "main.h"
#include "geruchsvernichter.h"
#include "math.h"
#include "stdio.h"

static uint8_t crc8(const uint8_t* data, uint8_t len);

// Sensirion Variables
uint16_t SHT_I2C_ADDR					= 0xE0;
uint16_t SGP_I2C_ADDR					= 0xB0;
double mTemperature 					= -250.0;									// gemessene Temperature
double mHumidity    					= -1.0;										// gemessene Feuchtigkeit
double comHumidity						= 0;										// Kompensation der Feuchtigkeit
uint16_t mTVOC       					= 0;										// gemessene VOC-Werte
uint16_t mECO2       					= 0;										// CO2
uint8_t mDataBuf[6];
uint8_t absoluteHumidity[2];														// absoluteHumidity[0]:Ganzzahliger Teil, absoluteHumidity[0]:Dezimale
uint8_t comData[5] 						= { 0x20, 0x61 , 0x00, 0x00, 0xFF };		// Register ADDR: 0x2061,  comData[2-3]: absoluteHumidity,  comData[4]: CRC

// Parameter of Si5351
const static int Si5351_I2C_ADDR		= 0xC0;
uint8_t Si5351_OutputAus[]				= { 0x03, 0xFF };
uint8_t Si5351_OutputEin[]				= { 0x03, 0x00 };
uint8_t Si5351_InterLoadCapacitance[]	= { 0xB7, 0xD2 };							// Reg.183		: Crystal Internal Load Capacitance = 10pF
uint8_t Si5351_PLLReset[]				= { 0xB1, 0xA0 };
uint8_t Si5351_CLK0Control[]			= { 0x10, 0x4F };
uint8_t Si5351_CLK1Control[]			= { 0x11, 0x4F };

// PLL -> Multiplier
// Si5351 : f_vco = 25 MHz * ( a + b/c )
// f_vco is the PLL_output, must be between 600 ... 900 MHz
// Reg.MSNAx by PLL_A
// When f_outCLK0 = 100 MHz,		set {0x1B, 0x01}, {0x1D, 0x0E}, others Reg.= 0x00
// When f_outCLK0 = 150 MHz,		set {0x1B, 0x01}, {0x1D, 0x10}, others Reg.= 0x00
// When f_outCLK0 = 112.5 MHz,	set {0x1B, 0x01}, {0x1D, 0x10}, others Reg.= 0x00
// When f_outCLK0 = 133.33 MHz,	set {0x1B, 0x01}, {0x1D, 0x10}, others Reg.= 0x00
uint8_t Si5351_MSNA_26[]								= { 0x1A, 0x00 };									// Multipler	: Register Nr.26
uint8_t Si5351_MSNA_27[]								= { 0x1B, 0x01 };									// Multipler	: Register Nr.27
uint8_t Si5351_MSNA_28[]								= { 0x1C, 0x00 };									// Multipler	: Register Nr.28
uint8_t Si5351_MSNA_29[]								= { 0x1D, 0x0E };									// Multipler	: Register Nr.29
uint8_t Si5351_MSNA_30[]								= { 0x1E, 0x00 };									// Multipler	: Register Nr.30
uint8_t Si5351_MSNA_31[]								= { 0x1F, 0x00 };									// Multipler	: Register Nr.31
uint8_t Si5351_MSNA_32[]								= { 0x20, 0x00 };									// Multipler	: Register Nr.32
uint8_t Si5351_MSNA_33[]								= { 0x21, 0x00 };									// Multipler	: Register Nr.33

// Divider
// Reg.MS0x by Channel_0 (CLK0)
// By Integer Mode : a = 4 or 6 or 8 ;  b = 0 ;  c = 1
// When f_outCLK0 = 100 MHz,		set {0x2B, 0x01}, {0x2D, 0x02}, others Reg.= 0x00 (a=8)
// When f_outCLK0 = 150 MHz,		set {0x2B, 0x01}, {0x2D, 0x01}, others Reg.= 0x00 (a=6)
// When f_outCLK0 = 112.5 MHz,	set {0x2B, 0x01}, {0x2D, 0x02}, others Reg.= 0x00
// When f_outCLK0 = 133.33 MHz,	set {0x2B, 0x01}, {0x2D, 0x01}, others Reg.= 0x00
uint8_t Si5351_MS0_42[]									= { 0x2A, 0x00 };									// Divider		: Register Nr.42
uint8_t Si5351_MS0_43[]									= { 0x2B, 0x01 };									// Divider		: Register Nr.43
uint8_t Si5351_MS0_44[]									= { 0x2C, 0x00 };									// Divider		: Register Nr.44  ;  R0_DIV[6:4] : 000b-111b -> 1/2/4/8/16/32/64/128
uint8_t Si5351_MS0_45[]									= { 0x2D, 0x01 };									// Divider		: Register Nr.45
uint8_t Si5351_MS0_46[]									= { 0x2E, 0x00 };									// Divider		: Register Nr.46
uint8_t Si5351_MS0_47[]									= { 0x2F, 0x00 };									// Divider		: Register Nr.47
uint8_t Si5351_MS0_48[]									= { 0x30, 0x00 };									// Divider		: Register Nr.48
uint8_t Si5351_MS0_49[]									= { 0x31, 0x00 };									// Divider		: Register Nr.49

// Check I2C Connection, if OK, turn off green LED -> SGP30 , turn off red LED -> Si5351
void Sensirion_checkI2C(void)
{
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);
	if(HAL_I2C_IsDeviceReady(&hi2c1, SGP_I2C_ADDR, 2, 50) == HAL_OK)
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
	}
	if(HAL_I2C_IsDeviceReady(&hi2c1, Si5351_I2C_ADDR, 2, 50) == HAL_OK)
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);
	}
}


// Functions measurement of SHTC1(RH/T)
void Sensirion_measureRHT(void)
{
	uint8_t cmd[2] = { 0x7C, 0xA2 };
	uint16_t valRHT;
	
	HAL_I2C_Master_Transmit(&hi2c1, SHT_I2C_ADDR, &cmd[0], 2, 50);
	HAL_Delay(15);
	HAL_I2C_Master_Receive(&hi2c1, SHT_I2C_ADDR+1, &mDataBuf[0], 6, 50);
	valRHT = (mDataBuf[0] << 8) + mDataBuf[1];
	mTemperature = -45 + 175 * (valRHT / 65535.0);
	valRHT = (mDataBuf[3] << 8) + mDataBuf[4];
	mHumidity = 100 * (valRHT / 65535.0);
	
	return;
}


// Function measurement of SGP30 (VOC)
void Sensirion_measureSGP(void)
{

	//	Sensirion_HumiCompensation();											// Absolute Humi. compensate
	
	uint8_t cmd[2] = { 0x20, 0x08 };
	
	HAL_I2C_Master_Transmit(&hi2c1, SGP_I2C_ADDR, &cmd[0], 2, 50);
	HAL_Delay(50);
	HAL_I2C_Master_Receive(&hi2c1, SGP_I2C_ADDR+1, &mDataBuf[0], 6, 50);
	mECO2 = (mDataBuf[0] << 8) | mDataBuf[1];
	mTVOC = (mDataBuf[3] << 8) | mDataBuf[4];
	
	return;
}


// Humidity Compensation
void Sensirion_HumiCompensation(void)
{
	comHumidity = 216.7 * ( (mHumidity/100) * 6.112 * exp(1.62*mTemperature/(243.12+mTemperature)) / (273.15+mTemperature) );
	absoluteHumidity[0] = (uint8_t)(comHumidity);
	comData[2] = absoluteHumidity[0];
	absoluteHumidity[1] = (uint8_t)((comHumidity-absoluteHumidity[0])*100);		// Ganzzahliger Teil
	comData[3] = absoluteHumidity[1];											// Dezimale
	comData[4] = crc8(absoluteHumidity, 2);										// CRC-Byte
	HAL_I2C_Master_Transmit(&hi2c1, SGP_I2C_ADDR, comData, 5, 50);
	return;	
}


// Initialize of SGP30 (VOC)
void Sensirion_initSGP(void)
{
	uint8_t cmd[2] = { 0x20, 0x03 };												// Reg.Command : sgp30_iaq_init
	HAL_I2C_Master_Transmit(&hi2c1, SGP_I2C_ADDR, &cmd[0], 2, 50);
	
	return;
}


// CRC check
static uint8_t crc8(const uint8_t* data, uint8_t len)
{
	uint8_t crc = 0xff;
	uint8_t byteCtr;
	for (byteCtr = 0; byteCtr < len; ++byteCtr) 
	{
		crc ^= (data[byteCtr]);
		for (uint8_t bit = 8; bit > 0; --bit)
		{
			if (crc & 0x80)
				{
					crc = (crc << 1) ^ 0x31;
        }
			else
				{
          crc = (crc << 1);
        }
    }
  }
	
	return crc;
}


// Initialize Clock Generator Si5351
// Operating Sequence : OutputAus -> All CHs PowerDown -> InterLoadCap. -> PLLMulti. -> PLL reset -> Multisynth. -> CLKxControl -> OutputEin
void Si5351(void)
{
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_OutputAus, 2, 50);
	for (int8_t i=0; i<8; i++)
	{
		uint8_t Si5351_PowerDdown[] = { 0x10+i, 0x80 };
		HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_PowerDdown, 2, 50);
	}
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_InterLoadCapacitance, 2, 50);
	
	// Set PLL Multiplier
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MSNA_26, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MSNA_27, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MSNA_28, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MSNA_29, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MSNA_30, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MSNA_31, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MSNA_32, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MSNA_33, 2, 50);
	
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_PLLReset, 2, 50);
	
	// Set Multisynth.Divider
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MS0_42, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MS0_43, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MS0_44, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MS0_45, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MS0_46, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MS0_47, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MS0_48, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_MS0_49, 2, 50);
	
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_CLK0Control, 2, 50);
	HAL_I2C_Master_Transmit(&hi2c1, Si5351_I2C_ADDR, Si5351_OutputEin, 2, 50);
	
	return;
}

